# Asistente APA 7.ª edición (español)

Herramientas para estudiantes e investigadores de habla hispana que quieren citar y dar
formato correcto a sus trabajos con las normas APA, 7.ª edición:

1. **Aplicación web** (Streamlit): pega tu texto o sube tu archivo Word y revisa citas,
   referencias, formato del documento y tablas.
2. **Asistente de IA**: instrucciones (`SYSTEM_PROMPT.md`) y guías (`docs/`) para crear un
   asistente que genera referencias y citas, corrige errores y explica el formato.

> Enlace de la aplicación: *(escribe aquí tu enlace de Streamlit cuando lo tengas)*

## Qué revisa la aplicación

- **Citas y referencias**: «&» en lugar de «y», 3 o más autores sin *et al.*, formas
  incorrectas de *et al.*, *s. f.* y *p.*/*pp.*, *ibid.*, citas textuales sin página y de 40
  palabras o más, DOI sin formato de URL, «Recuperado de», lugar de publicación, orden
  alfabético y correspondencia entre citas y lista de referencias.
- **Formato (archivo .docx)**: márgenes de 2,54 cm, fuente permitida, interlineado doble,
  sin espacio entre párrafos, sangría de 1,27 cm, sangría francesa en referencias y
  numeración de páginas.
- **Tablas (archivo .docx)**: «Tabla N» en negrita, título en cursiva en línea aparte, sin
  líneas verticales, «Nota.» en cursiva, numeración consecutiva, mención en el texto y
  tamaño de fuente entre 8 y 14 pt.

No puede verificar cursivas en títulos de libros y revistas, niveles de títulos, figuras,
el contenido interno de las tablas ni si los datos de una fuente son reales.

## Estructura del repositorio

```
apa7-asistente-es/
├── README.md
├── SYSTEM_PROMPT.md              # instrucciones del asistente de IA
├── streamlit_app.py              # aplicación web (un solo archivo)
├── requirements.txt              # librerías: streamlit y python-docx
├── docs/
│   ├── guia-formato-apa7.md      # formato del documento y cambios APA 6 → 7
│   ├── guia-tablas-apa7.md       # tablas: formato, notas, Word y lista de verificación
│   └── plantillas-referencias.md # plantillas de referencias y citas
└── ejemplos/
    ├── ejemplo-correcto.docx     # documento que cumple las reglas revisadas
    ├── ejemplo-con-errores.docx  # documento con errores para probar la aplicación
    └── texto-con-errores.txt     # texto para pegar en la pestaña «Pegar texto»
```

## Cómo probar la aplicación

1. **Pegar texto**: copia el contenido de `ejemplos/texto-con-errores.txt` y pégalo en la
   pestaña «Pegar texto».
2. **Subir archivo Word**: sube `ejemplos/ejemplo-con-errores.docx` y luego
   `ejemplos/ejemplo-correcto.docx` y compara los resultados.

## Cómo usar el asistente de IA

Copia el contenido de `SYSTEM_PROMPT.md` (desde la primera línea `---`) en las instrucciones
de tu asistente (Claude Project, GPT personalizado, Gemini Gem, etc.) y sube los tres
archivos de `docs/` como conocimiento.

## Advertencias

- Es una ayuda de estudio basada en reglas. **Verifica** el resultado con el manual oficial
  (https://apastyle.apa.org) y con las normas de tu institución, que pueden prevalecer.
- Los avisos marcados como «Revisar» son sospechas, no errores seguros.
- Las referencias jurídicas varían según el país.

*Proyecto independiente, sin afiliación con la American Psychological Association.*
